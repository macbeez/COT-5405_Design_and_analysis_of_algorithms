python3 LU-Parial_Decomposition.py
python3 CompletePivot.py

